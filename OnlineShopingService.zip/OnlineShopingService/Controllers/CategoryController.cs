﻿using OnlineShopingService.BusinessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using OnlineShopingService.DataAccessLayer.Repository.EntityFramework;
using System.Web.Http.Cors;

namespace OnlineShopingService.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    [RoutePrefix("api")]
    public class CategoryController : ApiController
    {
        private readonly BusinessLayer.IGeneric<Category> objCategory;
        public CategoryController(BusinessLayer.IGeneric<Category> category)
        {
            objCategory = category;
        }

        IHttpActionResult result = null;
        [Route("Category/GetAll")]
        [HttpGet]
        public IHttpActionResult GetCategory()
        {
            try
            {
                WebApiApplication.logger.Info("Category/GetAll called" + Environment.NewLine + DateTime.Now);
                IEnumerable<Category> CategoryList = objCategory.GetDetails();
                result = ResponseMessage(Request.CreateResponse(HttpStatusCode.OK, CategoryList));
            }
            catch (Exception ex)
            {
                result = ResponseMessage(Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message));
                WebApiApplication.logger.Error(ex.Message + Environment.NewLine + DateTime.Now);
            }

            return result;
        }
        [Route("Category/Get/{id}")]
        [HttpGet]
        public IHttpActionResult GetCategorybyID(int id)
        {
            try
            {
                WebApiApplication.logger.Info("Category/Get called" + Environment.NewLine + DateTime.Now);
                Category Category = objCategory.GetDetailsById(id);
                result = ResponseMessage(Request.CreateResponse(HttpStatusCode.OK, Category));
            }
            catch (Exception ex)
            {
                result = ResponseMessage(Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message));
                WebApiApplication.logger.Error(ex.Message + Environment.NewLine + DateTime.Now);
            }
            return result;
        }
        [Route("Category/Add")]
        [HttpPost]
        public IHttpActionResult AddCategory([FromBody]Category Category)
        {
            try
            {
                WebApiApplication.logger.Info("Category/Add called" + Environment.NewLine + DateTime.Now);
                objCategory.AddDetails(Category);
                result = ResponseMessage(Request.CreateResponse(HttpStatusCode.OK));
            }
            catch (Exception ex)
            {
                result = ResponseMessage(Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message));
                WebApiApplication.logger.Error(ex.Message + Environment.NewLine + DateTime.Now);
            }
            return result;
        }
        [Route("Category/Update")]
        [HttpPost]
        public IHttpActionResult UpdateCategory([FromBody]Category Category)
        {
            try
            {
                WebApiApplication.logger.Info("Category/Update called" + Environment.NewLine + DateTime.Now);
                objCategory.UpdateDetails(Category);
                result = ResponseMessage(Request.CreateResponse(HttpStatusCode.OK));
            }
            catch (Exception ex)
            {
                result = ResponseMessage(Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message));
                WebApiApplication.logger.Error(ex.Message + Environment.NewLine + DateTime.Now);
            }
            return result;
        }
        [Route("Category/Delete/{id}")]
        [HttpPost]
        public IHttpActionResult DeleteCategory(int id)
        {
            try
            {
                WebApiApplication.logger.Info("Category/Delete called" + Environment.NewLine + DateTime.Now);
                objCategory.DeleteDetails(id);
                result = ResponseMessage(Request.CreateResponse(HttpStatusCode.OK));
            }
            catch (Exception ex)
            {
                result = ResponseMessage(Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message));
                WebApiApplication.logger.Error(ex.Message + Environment.NewLine + DateTime.Now);
            }
            return result;
        }
    }
}
