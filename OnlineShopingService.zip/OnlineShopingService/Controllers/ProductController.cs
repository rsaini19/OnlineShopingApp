﻿using OnlineShopingService.BusinessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using OnlineShopingService.DataAccessLayer.Repository.EntityFramework;
using System.Web.Http.Cors;
using OnlineShopingService.DataAccessLayer.Repository.App;

namespace OnlineShopingService.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    [RoutePrefix("api")]
    public class ProductController : ApiController
    {
        private readonly BusinessLayer.IGeneric<Product> objProduct;
        private readonly Repository<Product> objProductsbyCategory;

        public ProductController(BusinessLayer.IGeneric<Product> product)
        {
            objProduct = product;
            objProductsbyCategory = new Repository<Product>(new OnlineShopingAppEntities2());
        }

        IHttpActionResult result = null;
        [Route("Product/GetAll")]
        [HttpGet]
        public IHttpActionResult GetProduct()
        {
            try
            {
                WebApiApplication.logger.Info("Product/GetAll called" + Environment.NewLine + DateTime.Now);
                IEnumerable<Product> productList = objProduct.GetDetails();
                result = ResponseMessage(Request.CreateResponse(HttpStatusCode.OK, productList));
            }
            catch (Exception ex)
            {
                result = ResponseMessage(Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message));
                WebApiApplication.logger.Error(ex.Message + Environment.NewLine + DateTime.Now);
            }

            return result;
        }
        [Route("Product/Get/{id}")]
        [HttpGet]
        public IHttpActionResult GetProductbyID(int id)
        {
            try
            {
                WebApiApplication.logger.Info("Product/Get called" + Environment.NewLine + DateTime.Now);
                Product product = objProduct.GetDetailsById(id);
                result = ResponseMessage(Request.CreateResponse(HttpStatusCode.OK, product));
            }
            catch (Exception ex)
            {
                result = ResponseMessage(Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message));
                WebApiApplication.logger.Error(ex.Message + Environment.NewLine + DateTime.Now);
            }
            return result;
        }
        [Route("Product/Add")]
        [HttpPost]
        public IHttpActionResult AddProduct([FromBody]Product product)
        {
            try
            {
                WebApiApplication.logger.Info("Product/Add called" + Environment.NewLine + DateTime.Now);
                product.CreatedDate = DateTime.Now;
                objProduct.AddDetails(product);
                result = ResponseMessage(Request.CreateResponse(HttpStatusCode.OK));
            }
            catch (Exception ex)
            {
                result = ResponseMessage(Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message));
                WebApiApplication.logger.Error(ex.Message + Environment.NewLine + DateTime.Now);
            }
            return result;
        }
        [Route("Product/Update")]
        [HttpPost]
        public IHttpActionResult UpdateProduct([FromBody]Product product)
        {
            try
            {
                WebApiApplication.logger.Info("Product/Update called" + Environment.NewLine + DateTime.Now);
                product.CreatedDate = DateTime.Now;
                objProduct.UpdateDetails(product);
                result = ResponseMessage(Request.CreateResponse(HttpStatusCode.OK));
            }
            catch (Exception ex)
            {
                result = ResponseMessage(Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message));
                WebApiApplication.logger.Error(ex.Message + Environment.NewLine + DateTime.Now);
            }
            return result;
        }
        [Route("Product/Delete/{id}")]
        [HttpPost]
        public IHttpActionResult DeleteProduct(int id)
        {
            try
            {
                WebApiApplication.logger.Info("Product/Delete called" + Environment.NewLine + DateTime.Now);
                objProduct.DeleteDetails(id);
                result = ResponseMessage(Request.CreateResponse(HttpStatusCode.OK));
            }
            catch (Exception ex)
            {
                result = ResponseMessage(Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message));
                WebApiApplication.logger.Error(ex.Message + Environment.NewLine + DateTime.Now);
            }
            return result;
        }

        [Route("Product/GetProductsbyCategory/{id}")]
        public IHttpActionResult GetProductsbyCategory(int id)
        {
            try
            {
                WebApiApplication.logger.Info("Product/GetProductsbyCategory" + Environment.NewLine + DateTime.Now);
                List<ProductDetails> products = objProductsbyCategory.GetProductbyCategoryId(id);
                result = ResponseMessage(Request.CreateResponse(HttpStatusCode.OK, products));
            }
            catch (Exception ex)
            {
                result = ResponseMessage(Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message));
                WebApiApplication.logger.Error(ex.Message + Environment.NewLine + DateTime.Now);
            }
            return result;
        }

        [Route("Product/GetProductAutoSearch/{prefix}")]
        public IHttpActionResult GetProductAutoSearch(string prefix)
        {
            try
            {
                WebApiApplication.logger.Info("Product/GetProductsbyCategory" + Environment.NewLine + DateTime.Now);
                List<proc_GetProduct_AutoSearch_Result> products = objProductsbyCategory.GetProductAutoSearch(prefix);
                result = ResponseMessage(Request.CreateResponse(HttpStatusCode.OK, products));
            }
            catch (Exception ex)
            {
                result = ResponseMessage(Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message));
                WebApiApplication.logger.Error(ex.Message + Environment.NewLine + DateTime.Now);
            }
            return result;
        }
    }
}
