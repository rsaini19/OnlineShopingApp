﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using OnlineShopingService.Models;
using OnlineShopingService.DataAccessLayer.Repository.App.Contract;
using OnlineShopingService.DataAccessLayer.Repository.App;
using OnlineShopingService.DataAccessLayer.Repository.EntityFramework;

namespace OnlineShopingService.BusinessLayer
{
    public class GenericDetails<TEntity> : IGeneric<TEntity> where TEntity: class
    {
        private readonly IRepository<TEntity> _repository;

        public GenericDetails()
        {
            _repository = new Repository<TEntity>(new OnlineShopingAppEntities2());
        }

        public void AddDetails(TEntity objEntity)
        {
            _repository.Insert(objEntity);
        }

        public void DeleteDetails(int id)
        {
            _repository.Delete(id);
        }

        public TEntity GetDetailsById(int id)
        {
            return _repository.GetByID(id);
        }

        public IEnumerable<TEntity> GetDetails()
        {
            return _repository.Get();
        }

        public void UpdateDetails(TEntity objEntity)
        {
            _repository.Update(objEntity);
        }
    }
}