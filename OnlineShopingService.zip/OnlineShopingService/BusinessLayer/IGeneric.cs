﻿using OnlineShopingService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineShopingService.BusinessLayer
{
    public interface IGeneric<TEntity> where TEntity: class
    {
        IEnumerable<TEntity> GetDetails();

        TEntity GetDetailsById(int id);

        void AddDetails(TEntity objEntity);

        void UpdateDetails(TEntity objEntity);

        void DeleteDetails(int id);
    }
}
