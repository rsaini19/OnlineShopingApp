﻿using OnlineShopingApp.Master_Caching;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace OnlineShopingApp
{
    public class MvcApplication : System.Web.HttpApplication
    {
        public HttpClient client = null;
        string baseUrl = string.Empty;
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
        }
        protected void Session_Start()
        {
            client = new HttpClient();
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            baseUrl = ConfigurationManager.AppSettings["baseurl"];
            client.BaseAddress = new Uri(baseUrl);
            Session["ApiSetting"] = client;

            CategoryCaching.GetAllCategory();
            CategoryCaching.GetCategoryById();
        }
        protected void Session_End()
        {
            Session.Abandon();
        }
    }
}
