﻿using Newtonsoft.Json;
using OnlineShopingApp.Filters;
using OnlineShopingApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace OnlineShopingApp.Controllers
{
    [NoCache]
    public class CategoryController : Controller
    {
        HttpClient client = null;
        string apiUrl = string.Empty;

        public CategoryController()
        {
            client = (HttpClient)System.Web.HttpContext.Current.Session["ApiSetting"];
            apiUrl = client.BaseAddress.AbsoluteUri + "Category/";
        }

        // GET: Category
        public ActionResult Index()
        {
            List<CategoryViewModel> CategoryList = new List<CategoryViewModel>();
            apiUrl = apiUrl + "GetAll";

            var GetTask = client.GetAsync(apiUrl);
            GetTask.Wait();

            var result = GetTask.Result;

            if (result.IsSuccessStatusCode)
            {
                var responseData = result.Content.ReadAsStringAsync().Result;
                CategoryList = JsonConvert.DeserializeObject<List<CategoryViewModel>>(responseData);
            }

            Dispose(true);

            return View(CategoryList);
        }

        // GET: Category/Details/5
        public ActionResult Details(int id)
        {
            CategoryViewModel Category = new CategoryViewModel();
            apiUrl = apiUrl + "Get/" + id;

            var GetTask = client.GetAsync(apiUrl);
            GetTask.Wait();

            var result = GetTask.Result;

            if (result.IsSuccessStatusCode)
            {
                var responseData = result.Content.ReadAsStringAsync().Result;
                Category = JsonConvert.DeserializeObject<CategoryViewModel>(responseData);
            }
            if (Category == null)
            {
                return HttpNotFound();
            }
            Dispose(true);
            return View(Category);
        }

        // GET: Category/Create
        public ActionResult Create()
        {
            CategoryViewModel category = new CategoryViewModel();
            return View(category);
        }

        // POST: Category/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(CategoryViewModel category)
        {
            apiUrl = apiUrl + "Add";

            if (category != null)
            {
                var stringContent = new StringContent(JsonConvert.SerializeObject(category), Encoding.UTF8, "application/json");

                var postTask = client.PostAsync(apiUrl, stringContent);
                postTask.Wait();

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }

                ModelState.AddModelError(string.Empty, "Server Error. Please contact administrator.");
                Dispose(true);
            }

            return View(category);
        }

        // GET: Category/Edit/5
        public ActionResult Edit(int? id)
        {
            CategoryViewModel Category = new CategoryViewModel();
            apiUrl = apiUrl + "Get/" + id;

            var GetTask = client.GetAsync(apiUrl);
            GetTask.Wait();

            var result = GetTask.Result;

            if (result.IsSuccessStatusCode)
            {
                var responseData = result.Content.ReadAsStringAsync().Result;
                Category = JsonConvert.DeserializeObject<CategoryViewModel>(responseData);
            }
            if (Category == null)
            {
                return HttpNotFound();
            }
            Dispose(true);
            return View(Category);
        }

        // POST: Category/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "CategoryId,CategoryName,CategoryDesc,CategoryPrice,CategoryId")] CategoryViewModel CategoryViewModel)
        {
            apiUrl = apiUrl + "Update";

            var stringContent = new StringContent(JsonConvert.SerializeObject(CategoryViewModel), Encoding.UTF8, "application/json");

            var postTask = client.PostAsync(apiUrl, stringContent);
            postTask.Wait();

            var result = postTask.Result;
            if (result.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }

            ModelState.AddModelError(string.Empty, "Server Error. Please contact administrator.");
            Dispose(true);
            return View(CategoryViewModel);
        }

        // GET: Category/Delete/5
        public ActionResult Delete(int? id)
        {
            CategoryViewModel Category = new CategoryViewModel();
            apiUrl = apiUrl + "Get/" + id;

            var GetTask = client.GetAsync(apiUrl);
            GetTask.Wait();

            var result = GetTask.Result;

            if (result.IsSuccessStatusCode)
            {
                var responseData = result.Content.ReadAsStringAsync().Result;
                Category = JsonConvert.DeserializeObject<CategoryViewModel>(responseData);
            }
            if (Category == null)
            {
                return HttpNotFound();
            }
            Dispose(true);
            return View(Category);
        }

        // POST: Category/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int? id)
        {
            apiUrl = apiUrl + "Delete/" + id;
            var stringContent = new StringContent(id.ToString(), Encoding.UTF8, "application/json");

            var deleteTask = client.PostAsync(apiUrl, stringContent);
            deleteTask.Wait();
            var result = deleteTask.Result;

            Dispose(true);
            return RedirectToAction("Index");
        }

        [NonAction]
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                client = null;
            }
            base.Dispose(disposing);
        }
    }
}