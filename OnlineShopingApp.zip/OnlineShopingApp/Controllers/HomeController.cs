﻿using OnlineShopingApp.Master_Caching;
using OnlineShopingApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OnlineShopingApp.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        [HttpPost]
        public ActionResult GetMenuData()
        {
            List<MenuModel> menus = new List<MenuModel>();
            List<CategoryViewModel> lstCategory = CategoryCaching.GetAllCategory();

            if (lstCategory != null && lstCategory.Count > 0)
            {
                foreach (var category in lstCategory)
                {
                    menus.Add(new MenuModel { Name = category.CategoryName, Url = Url.Action("ProductCategory", "Product", new { id = category.CategoryId }) });
                }
            }
            return Json(menus);
        }
    }
}