﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace OnlineShopingApp.Models
{
    public class ProductViewModel
    {
        private DateTime _createdDate;
        [Key]
        [Required]
        public int ProductId { get; set; }
        [DisplayName("Product Name")]
        [Required]
        public string ProductName { get; set; }
        [DisplayName("Description")]
        public string ProductDesc { get; set; }
        [DisplayName("Price")]
        [Required]
        public double ProductPrice { get; set; }
        [DisplayName("Image")]
        public byte[] ProductImage { get; set; }
        [Required]
        [DisplayName("Category")]
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        [DisplayName("Updated Date")]
        public System.DateTime CreatedDate
        {
            get { return _createdDate; }
            set { _createdDate = value; }
        }
    }
}