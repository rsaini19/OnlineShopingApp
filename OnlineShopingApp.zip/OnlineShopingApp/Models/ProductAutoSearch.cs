﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OnlineShopingApp.Models
{
    public class ProductAutoSearch
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
    }
}