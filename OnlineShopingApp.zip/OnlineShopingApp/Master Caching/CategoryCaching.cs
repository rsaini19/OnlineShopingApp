﻿using Newtonsoft.Json;
using OnlineShopingApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;

namespace OnlineShopingApp.Master_Caching
{
    public static class CategoryCaching
    {
        static HttpClient client = (HttpClient)System.Web.HttpContext.Current.Session["ApiSetting"];
        static string apiUrl = string.Empty;

        public static List<CategoryViewModel> GetAllCategory()
        {
            List<CategoryViewModel> listCategory = new List<CategoryViewModel>();
            try
            {
                apiUrl = client.BaseAddress.AbsoluteUri + "Category/GetAll";
                var GetTask = client.GetAsync(apiUrl);
                GetTask.Wait();

                var result = GetTask.Result;

                if (result.IsSuccessStatusCode)
                {
                    var responseData = result.Content.ReadAsStringAsync().Result;
                    listCategory = JsonConvert.DeserializeObject<List<CategoryViewModel>>(responseData);
                }

            }
            catch (Exception ex)
            {
                throw;
            }
            return listCategory;
        }

        public static Dictionary<int, string> GetCategoryById()
        {
            Dictionary<int, string> dicCategory = new Dictionary<int, string>();
            try
            {
                List<CategoryViewModel> lstcategory = GetAllCategory();

                if (lstcategory != null && lstcategory.Count > 0)
                {
                    CategoryViewModel categorydetails = new CategoryViewModel();
                    foreach (var category in lstcategory)
                    {
                        apiUrl = client.BaseAddress.AbsoluteUri + "Category/Get/" + category.CategoryId;
                        var GetTask = client.GetAsync(apiUrl);
                        GetTask.Wait();

                        var result = GetTask.Result;
                        if (result.IsSuccessStatusCode)
                        {
                            var responseData = result.Content.ReadAsStringAsync().Result;
                            categorydetails = JsonConvert.DeserializeObject<CategoryViewModel>(responseData);
                        }
                        dicCategory.Add(category.CategoryId, categorydetails.CategoryName);
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return dicCategory;
        }
    }
}